<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<div class="awdr_bulk_adjustment_card_group" style="display: none;">
    <!--<div class="awdr_simple_discount awdr_common_border_class">
        <b><?php /*_e('10% Store Wide Discount bulk', 'woo-discount-rules');*/?></b>
        <form>
            <input type="hidden" name="awdr_simple_discount" value="1">
            <button class="button" type="submit"><?php /*_e('Create', 'woo-discount-rules');*/?></button>
        </form>
        <a style="display: none;" href=""><?php /*_e('Edit Rule', 'woo-discount-rules');*/?></a>
    </div>
    <div class="awdr_simple_discount awdr_common_border_class">
        <b><?php /*_e('20% Store Wide Discount bulk', 'woo-discount-rules');*/?></b>
        <form>
            <input type="hidden" name="awdr_simple_discount" value="1">
            <button class="button" type="submit"><?php /*_e('Create', 'woo-discount-rules');*/?></button>
        </form>
        <a style="display: none;" href=""><?php /*_e('Edit Rule', 'woo-discount-rules');*/?></a>
    </div>-->
</div>